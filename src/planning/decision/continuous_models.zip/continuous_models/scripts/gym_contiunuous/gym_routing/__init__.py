from gym.envs.registration import register

register(
    id='zzz-v1',
    entry_point='gym_routing.envs:ZZZCarlaEnv'
    
)
