# CARLA Control RQT Plugin

If `carla_ros_bridge` is configured in synchronous-mode, this plugin can be used to control the stepping.

## Startup

You can start it e.g.:

    rqt --standalone rqt_carla_control

