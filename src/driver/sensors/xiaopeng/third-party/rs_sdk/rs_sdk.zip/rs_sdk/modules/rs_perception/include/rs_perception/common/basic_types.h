/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef ROBOSENSE_BASIC_TYPES_H
#define ROBOSENSE_BASIC_TYPES_H

#include <chrono>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <omp.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include "rs_perception/common/common.h"

//#define RESET   "\033[0m"
//#define BLACK   "\033[30m"      /* Black */
//#define RED     "\033[31m"      /* Red */
//#define GREEN   "\033[32m"      /* Green */
//#define YELLOW  "\033[33m"      /* Yellow */
//#define BLUE    "\033[34m"      /* Blue */
//#define MAGENTA "\033[35m"      /* Magenta */
//#define CYAN    "\033[36m"      /* Cyan */
//#define WHITE   "\033[37m"      /* White */
//#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
//#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
//#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
//#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
//#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
//#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
//#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
//#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

#define COUT(X) std::cout << std::setiosflags(std::ios::fixed) << X << "\033[3m" \
                          << "\r" << std::flush << std::endl
#define COUTR(X) std::cout << std::setiosflags(std::ios::fixed) << "\033[1;31m " << X << "\033[0m" \
                           << "\r" << std::flush << std::endl
#define COUTG(X) std::cout << std::setiosflags(std::ios::fixed) << "\033[1;32m " << X << "\033[0m" \
                           << "\r" << std::flush << std::endl
#define COUTY(X) std::cout << std::setiosflags(std::ios::fixed) << "\033[1;33m " << X << "\033[0m" \
                           << "\r" << std::flush << std::endl
#define COUTB(X) std::cout << std::setiosflags(std::ios::fixed) << "\033[1;34m " << X << "\033[0m" \
                           << "\r" << std::flush << std::endl
#define COUTP(X) std::cout << std::setiosflags(std::ios::fixed) << "\033[1;35m " << X << "\033[0m" \
                           << "\r" << std::flush << std::endl

namespace robosense {
namespace perception {

//define some common value
const double PI_OVER_180 = (0.0174532925);
const double RS_EPS = (1e-6);
const double RS_MAX = (1e6);
const double RS_MIN = (-1e6);
const size_t HISTORY_BUFF_SIZE = 10;
const size_t TRACK_SEQ_EST_SIZE = 10;
const float OBJ_OBSERVE_NEAR_DIST = 15.f;
const size_t GEO_DISTRIBUTE_BIN_SIZE = 10;

enum ErrorCode {
    ErrCode_Success = 0,
    ErrCode_NullInput = 1,
    ErrCode_BadRotateCalib = 2,
    ErrCode_BadHeightCalib = 3,
    ErrCode_GndInitFalse = 4
};

typedef pcl::PointXYZI Point;
typedef pcl::PointCloud<Point> PointCloud;
typedef pcl::PointCloud<Point>::Ptr PointCloudPtr;
typedef pcl::PointCloud<Point>::ConstPtr PointCloudConstPtr;

enum class ObjectType {
    UNKNOW = 0,
    PED = 1,
    BIC = 2,
    CAR = 3,
    TRUCK_BUS = 4,
    ULTRA_VEHICLE = 5,
    MAX_OBJ_TYPE_NUM = 6,
};

enum class MotionType {
    UNKNOW = 0,
    MOVING = 1,
    STATIC = 2,
    STOPED = 3,
    MAX_MOTION_STATE_NUM = 4,
};

typedef pcl::PointXYZ PolygonType;
typedef pcl::PointCloud<PolygonType> Polygon;
typedef pcl::PointCloud<PolygonType>::Ptr PolygonPtr;

template<typename T>
std::string num2str(T num, int precision) {
    std::stringstream ss;
    ss.setf(std::ios::fixed, std::ios::floatfield);
    ss.precision(precision);
    std::string st;
    ss << num;
    ss >> st;

    return st;
}

class Timer {
public:
    Timer() { tic(); }

    void tic() { _start = std::chrono::system_clock::now(); }

    double toc(bool reset = false) {
        auto time = std::chrono::system_clock::now();
        std::chrono::duration<double, std::milli> dur = time - _start;
        if (reset) {
            tic();
        }
        return dur.count();
    }

private:
    std::chrono::time_point<std::chrono::system_clock> _start;
};

struct Header {
    double timestamp;
    unsigned int seq;
    std::string parent_frame_id;
    std::string frame_id;
};

struct alignas(16) Range1D {
    Range1D() = default;

    Range1D(float min_v, float max_v);

    Range1D(const Range1D &r);

    Range1D &operator=(const Range1D &r);

    bool isValid() const;

    float min = 0, max = 0;
};

/**
 * @brief Range definitions for 2D
 */
struct alignas(16) Range2D {
    Range2D() = default;

    Range2D(float x_min, float x_max, float y_min, float y_max);

    Range2D(const Range2D &r);

    Range2D &operator=(const Range2D &r);

    bool isValid() const;

    float xmin = 0, xmax = 0, ymin = 0, ymax = 0;
};

/**
 * @brief Range definitions for 3D
 */
struct alignas(16) Range3D {
    Range3D() = default;

    Range3D(float x_min, float x_max, float y_min, float y_max, float z_min, float z_max);

    Range3D(const Range3D &r);

    Range3D &operator=(const Range3D &r);

    bool isValid() const;

    float xmin = 0, xmax = 0, ymin = 0, ymax = 0, zmin = 0, zmax = 0;
};

struct alignas(16) BBox {

    typedef std::shared_ptr<BBox> Ptr;
    typedef std::shared_ptr<const BBox> ConstPtr;

    BBox() = default;

    BBox(const Eigen::Vector3f &center, const Eigen::Vector3f &size, const Eigen::Vector3f &dir);

    BBox(const Eigen::Vector3f &center, const Eigen::Vector3f &size, const float &ang);

    float area() const;

    float volume() const;

    float ratio() const;

    bool isNull() const;

    bool isEqual(const BBox &box) const;

    void corners(std::vector<Eigen::Vector3f> &corners) const; // get 8 corners from a box
    Eigen::Vector3f anchor() const;                            // get the nearest corner from a box

    BBox transform(const Eigen::Matrix4f &trans_mat) const; // transform box according a given trans
    BBox scale(float ratio) const;                          // scaling the box according a unified scalar
    BBox scale(Eigen::Vector3f ratio) const;                // scaling the box according scalar
    BBox resize(const Eigen::Vector3f &new_size, bool align = true) const;

    BBox trans(const Eigen::Vector3f &t) const;

    BBox rotate2d(float angle) const;

    BBox resetDir(const Eigen::Vector3f new_dir) const;

    BBox resetAngle(float angle) const;

    bool isInside(const Eigen::Vector3f point) const;

    int relationWith(const BBox &box) const;

    Eigen::Vector3f size = Eigen::Vector3f::Zero();
    Eigen::Vector3f center = Eigen::Vector3f::Zero();
    Eigen::Vector3f heading = Eigen::Vector3f(1, 0, 0);
    float angle = 0.f; /**< yaw angle of bbox direction, coincide with heading*/
};

/**
 * @brief pose
 */
struct alignas(16) Pose //
{
    float x = 0.f, y = 0.f, z = 0.f, roll = 0.f, pitch = 0.f, yaw = 0.f;
};

/*
 * @brief as part of attibutes of object
 */
struct alignas(16) DynamicInfo {
    float foreground_confidence = 0.f, max_foreground_confidence = 0.f, min_foreground_confidence = 1.f; //
    float dynamic_confidence = 0.f, max_dynamic_confidence = 0.f, min_dynamic_confidence = 1.f;
};

/*
 * @brief as one basic element of output
 */
struct alignas(16) FreeSpaceInfo {

    //----------------------header info-----------------------
    //timestamp of the object
    double timestamp = 0.f;
    //source device code where the underlaying data come from.
    unsigned int device_code = 0; //default is 0, for different devices
    float distance = 0.f;
    float yaw_angle = 0.f;
    float free_prob = 0.f;

    typedef std::shared_ptr<FreeSpaceInfo> Ptr;
    typedef std::shared_ptr<const FreeSpaceInfo> ConstPtr;
};

//========================================config args============================================

/**
 * @brief ObjectLimit parameters container, in order to filter out background and static objects so that the following tracking
 * and classification can focus on the foreground dynamic objects, the lidar assumed to be mounted horizontally.
 */
struct alignas(16) ObjectLimit {
    /**<height threshold for an object's absolute height from the ground*/
    float obj_max_height = 5.f;
    /**<height threshold for an object size to be detected*/
    float obj_size_height = 4.f;
    /**<length threshold for an object size to be detected*/
    float obj_size_length = 3.f;
    /**<width threshold for an object size to be detected*/
    float obj_size_width = 2.f;
    /**<the ratio of height and length threshold for an object to be detected*/
    float obj_length_width_ratio = 10.f;
    /**< possible vechile-like object area restriction*/
    float obj_max_area = 5.f;
};

struct alignas(16) DeepDetectionConfig {
    //detect range
    Range3D detect_range = Range3D(-60, 60, -60, 60, -3, 7);
    //cnn qutification unit size
    float unit_size = 0.1875f;
    //detect confidence threshold
    float obstacle_confidence_thd = 0.5f;
    //detect confidence threshold
    float object_confidence_thd = 0.1f;
    //height threshold for height regress
    float regress_height_thd = 0.5f;
    //pointcloud density base coefficient
    float density_base = 1.0f;
    // use pointcloud intensity normalization or not
    bool enable_intensity_normalize = false;
    // use low precision inference or not
    bool enable_fp_16 = false;
    // pre-defined memory cache size = 2^max_workspace (byte)
    unsigned int max_workspace = 30;
    //minimal points for detection
    unsigned int min_pts_num = 3;
    // height threshold for ground detection
    float ground_height_thd = 1.2f;
    // maximum height error within a cell for ground detection
    float ground_h_error_thd = 0.2f;
    // iou threhold for merge object
    float overlap_thd = 0.5f;
};


struct alignas(16) DeepDetectionConfig2 {
    // input feature size
    unsigned int rows = 64;
    unsigned int cols = 512;
    // detection range
    float range = 150.0f;
    // point height, pitch and yaw range
    float min_height = -5.0f;
    float max_height = 5.0f;
    float min_theta = -15.0f;
    float max_theta = 5.0f;
    float min_phi = -60.0f;
    float max_phi = 60.0f;
    //minimal points for detection
    unsigned int min_pts_num = 3;
    // voxel size
    float delta_x = 0.5f;
    float delta_y = 0.5f;
    // use intensity channel or not
    bool use_intensity = false;
    // use pointcloud intensity normalization or not
    bool enable_intensity_normalize = false;
    // use low precision inference or not
    bool enable_fp_16 = false;
    // pre-defined memory cache size = 2^max_workspace (byte)
    unsigned int max_workspace = 30;
    // height threshold for ground detection
    float ground_height_thd = 1.2f;
    // maximum height error within a cell for ground detection
    float ground_h_error_thd = 0.2f;
    // grid size of a cell for ground detection
    float ground_grid_size = 0.25f;
};


struct alignas(16) RefineDetectionConfig {
    //use post refine for dnn based detecion or not
    bool enable_detection_refine = false;
    //use a second stage to make complement for detection
    Range3D refine_range = Range3D(-40, 40, -40, 40, -3, 7);
    //use geometry filter or not
    bool enable_geo_filter = true;
    //use defined geometry setting to filter the second complementary detection stage
    ObjectLimit obj_limit;
    //use upper space detect or not for second complementary detection stage
    bool enable_upper_detect = false;
    //minimal points for detection
    unsigned int min_pts_num = 3;
    // iou threhold for merge object
    float overlap_thd = 0.5f;
};

//struct alignas(16) TrackingConfig
//{
//    //use tracking or not
//    bool enable_tracking = true;
//    //how long to predict when object missed
//    double predict_time = 0.5f;
//    //how long the history to cache for poster planning module
//    unsigned int history_num = HISTORY_BUFF_SIZE;
//    //how long the sequence to evaluate the robustness for a tracker
//    unsigned int eva_seq_size = TRACK_SEQ_EST_SIZE;
//    //use tracking to optimaze object pose estimation or not
//    bool enable_track_optimize = false;
//};

struct alignas(16) TrackingConfig {
    //use tracking or not
    bool enable_tracking = true;
    //use tracking to optimaze object pose estimation or not
    bool enable_track_optimize = true;
    //use adaptive filter gain
    bool enable_adaptive_filter_gain = true; //TODO： problem
    //use filter state check
    bool enable_check_filter_state = false; //TODO： problem
    //use weighted filter for direction
    bool enable_weighted_direction_filter = false;
    //use direction cue for improve filter
    bool enable_direction_cue_to_filter = false; //TODO： problem
    //use adaptive filter measure noise estimate
    bool enable_adaptive_measure_noise_estimate = false;
    //use history improve filter
    bool enable_history_improve_filter = false;
    //use check static object
    bool enable_check_static_obj = false;
    //how long to predict when object missed
    double predict_time = 0.5f;
    //how long the history to cache for poster planning module
    unsigned int history_num = HISTORY_BUFF_SIZE;
    //how long the sequence to evaluate the robustness for a tracker
    unsigned int eva_seq_size = TRACK_SEQ_EST_SIZE;
    //basic static object velocity noise
    float basic_velocity_noise = 0.4;
    //object associate threshold: for 10Hz: 3.0, for 2Hz: 10.0
    float match_distance_max = 3.0;
};

struct alignas(16) DynamicDetectionConfig {
    //use dynamic detecion or not
    bool enable_dynamic_detection = true;
    //dynamic detection range radius
    float dynamic_detect_range = 80;
    //dynamic detection frustum range
    float min_hori_angle = -180;
    float max_hori_angle = 180;
    float min_vert_range = -1.f;
    float max_vert_range = 4.5f;
};

struct alignas(16) FreespaceDetectionConfig {
    //enable freespace detection or not
    bool enable_freespace_detection = false;
    Range1D vertical_range = Range1D(-1.f, 4.5f);
    float min_hori_angle = -180.;
    float max_hori_angle = 180.;
    unsigned int sector_num = 1600;
    float free_width_thre = 1.;
};

/**
 * @brief lidar device type related parameters, mainly for rotated lidar
 */
struct alignas(16) LidarConfig {
    /**< lidar device id, used for multi-station post-fusion*/
    unsigned int device_id = 0;
    /**< lidar angle resolution between points in same line, with degree unit*/
    float hori_resolution = 0.2f;
    /**< lidar angle resolution between lines, with degree unit*/
    float vert_resolution = 0.5f;
};

struct alignas(16) CommonConfig {
    //lidar info
    LidarConfig lidar_info;
    //use auto align or not
    bool enable_auto_align = true;
    //ignore the zone for self-vehicle
    Range3D ignore_range = Range3D(-0.5, 5.5, -1.5, 1.5, -3, 2);
    //use inner zone specific process for fusion mode or not
    bool enable_fusion_adjust = true;
    //use height transform for old model compatibility or not
    bool enable_height_adjust = false;
    //classification post-enhance
    bool enable_class_enhance = false; //
    //use ROI-map or not
    bool enable_roi = false;
};

/**
 * @brief filtering dust or tail gas caused by vehicle moving
 */
struct alignas(16) PostDenoiseConfig {
    //use post filtering or not
    bool enable_post_denoise_filter = false;
    //post denoise range setting
    Range3D post_denoise_range = Range3D(-10, 10, -5, 5, -3, 7);
    float post_denoise_filter_thd = 0.5f;
};

/**
 * @brief tracker info container struct
 */
class alignas(16) PeceptionUsrConfig : public CommonBase {
public:
    void load(const std::string &filename);

    void load(const YAML::Node &cfg);

    CommonConfig common_config;

    //deeplearning based detection method args for method 1
    DeepDetectionConfig deep_detection_config;

    //deeplearning based detection method args for method 2
    DeepDetectionConfig2 deep_detection_config2;

    //a second refine stage followed deeplearning detection
    RefineDetectionConfig refine_detection_config;

    //tracking args
    TrackingConfig tracking_config;

    //dynamic&freespace detection config
    DynamicDetectionConfig dynamic_detect_config;

    //freespace detection config
    FreespaceDetectionConfig freespace_detect_config;

    //post denoies config
    PostDenoiseConfig post_denoise_config;
};

class alignas(16) LidarMountConfig : public CommonBase {

public:
    LidarMountConfig();

    LidarMountConfig(const LidarMountConfig &pa);

    LidarMountConfig &operator=(const LidarMountConfig &pa);

    float trans_to_vehicle_x = 0.f;
    float trans_to_vehicle_y = 0.f;
    float lidar_height = 0.f;

    void load(const std::string &filename);

    void load(const YAML::Node &cfg);
};

} // namespace perception
} // namespace robosense

#endif //ROBOSENSE_BASIC_TYPES_H
