/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef ROBOSENSE_OBJECT_H
#define ROBOSENSE_OBJECT_H

#include <Eigen/Core>
#include <boost/circular_buffer.hpp>
#include "rs_perception/common/basic_types.h"

namespace robosense {
namespace perception {

template<typename PointT>
class alignas(16) Object {

public:
    typedef pcl::PointCloud<PointT> PointCloud;
    typedef typename PointCloud::Ptr PointCloudPtr;
    typedef typename PointCloud::ConstPtr PointCloudConstPtr;

    typedef std::shared_ptr<Object<PointT>> Ptr;
    typedef std::shared_ptr<const Object<PointT>> ConstPtr;

    Object(uint32_t dev_code = 0);

    Object(PointCloudPtr pcloud, uint32_t dev_code = 0);

    //-------------functions-----------------
    //deep copy.
    void clone(const Object<PointT> &m);

    //debug output to console.
    void info() const;

    //output to file.
    void print(const std::string &filename) const;

    //object transform.
    void
    transform(typename Object<PointT>::Ptr object_trans, const Eigen::Matrix4f &trans_mat, bool with_full = true) const;

    void transform(const Eigen::Matrix4f &trans_mat, bool with_full = true);

    //when pointcloud changes, must rebuild the box and polygon info.
    void buildObject();

    //----------------------header info-----------------------
    //timestamp of the object
    double timestamp = 0.f;
    //source device code where the underlaying data come from.
    uint32_t device_code = 0;

    int mode = -1;

    //---------------------object level-----------------------
    int id = -1;
    PointCloudPtr cloud;
    PolygonPtr polygon;

    Eigen::Vector3f anchor = Eigen::Vector3f::Zero();      //stable anchor point, as lidar points varies dramatically, usually use bary center as init.
    Eigen::Vector3f center = Eigen::Vector3f::Zero();      //geometry center for bounding box.
    Eigen::Vector3f size = Eigen::Vector3f::Zero();
    Eigen::Vector3f direction = Eigen::Vector3f(1, 0,
                                                0); //direction for the obstacle, will be refined by tracking, as the direction should be coincidence with velocity direction.

    float detect_confidence = 0.f; //obstacle existence confidence.

    Eigen::Vector3f nearest_point = Eigen::Vector3f::Zero(); //nearest corner point of object to lidar.
    Eigen::Vector3f left_point = Eigen::Vector3f::Zero();    //clock-wise the leftmost point of the bostacle.
    Eigen::Vector3f right_point = Eigen::Vector3f::Zero();   //clock-wise the rightmost point of the bostacle.

    float distance = 0.f; //distance between nearest point of obstacle and the lidar.
    float yaw = 0.f; //yaw angle of the obstacle location relative to the lidar coordinate.
    float fov = 0.f; //occupied FOV (>=0) in yaw w.r.t. lidar coordinate, maybe useful in occupation planing or freespace related.
    uint32_t point_num = 0; // points number of the obstacle.

    //---------------------classification info-------------------
    ObjectType type = ObjectType::UNKNOW;
    float type_confidence = 0.f; // classification confidence,
    std::vector<float> latent_types;

    //---------------------motion state prediction---------------------
    MotionType motion_state = MotionType::UNKNOW;

    //---------------------tracking info-------------------------
    bool is_track_converged = false;
    int tracker_id = -1;

    Eigen::Vector3f velocity = Eigen::Vector3f::Zero();
    Eigen::Matrix3f velocity_cov;
    float velocity_uncertainty = 0.f; // uncertainty from sequential analysis from historical velocities
    Eigen::Vector3f ave_velocity = Eigen::Vector3f::Zero();

    Eigen::Vector3f acceleration = Eigen::Vector3f::Zero();
    Eigen::Matrix3f acceleration_cov;
    float acceleration_uncertainty = 0.f; // uncertainty from sequential analysis from historical accelerations
    Eigen::Vector3f ave_acceleration = Eigen::Vector3f::Zero();

    float angle_velocity = 0.f;
    float angle_velocity_cov = 0.f;
    float angle_velocity_uncertainty = 0.f;
    float ave_angle_velocity = 0.f;

    float asso_quality = 0.f;        //the association quality for the current obstacle when linked into a exist tracker.
    float tracker_quality = 0.f; // the estimation quality for the tracker where the obstacle in.
    double tracking_time = 0.f;  // the life-time for the tracker which the current obstacle belong to.

    //=======optional: supplement attributes=======

    float foreground_confidence = 0.f;
    float dynamic_confidence = 0.f;

    boost::circular_buffer<Eigen::Vector3f> trajectory;
    boost::circular_buffer<Eigen::Vector3f> history_velocity;
};

} // namespace perception

} // namespace robosense

#endif //ROBOSENSE_OBJECT_H
