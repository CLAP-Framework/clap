/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/common.h>
#include <pcl/common/transforms.h>
#include "rs_perception/common/basic_types.h"

#ifndef ROBOSENSE_GEOBASE_H
#define ROBOSENSE_GEOBASE_H


namespace robosense {
namespace perception {

template<typename PointT>
struct alignas(16) GeoUtil {


    typedef pcl::PointCloud<PointT> PointCloud;
    typedef typename PointCloud::Ptr PointCloudPtr;
    typedef typename PointCloud::ConstPtr PointCloudConstPtr;


    static Eigen::Vector3f calcCloudBarycenter(PointCloudConstPtr cloud);

    static std::vector<float>
    calcDistriFeature(PointCloudConstPtr cloud, Eigen::Vector3i bin_size = Eigen::Vector3i(8, 8, 8));

    static bool isInrange2D(const PointT &p, const Range2D &range);

    static bool isInrange3D(const PointT &p, const Range3D &range);

    static void removeNanPoints(PointCloudPtr in_out_cloud);

    /**
     * geometry transformes
     * */

    static Eigen::Matrix4f calcRotationMatrix(const Eigen::Vector3f &before_vector, const Eigen::Vector3f &after_vector,
                                              float &rotation_angle);

    static Eigen::Matrix4f calcRotationMatrix(const float &angle, const Eigen::Vector3f &axis_vector);

    static Eigen::Matrix4f calcRotationMatrix(const Eigen::Vector3f &angle);

    static Eigen::Matrix4f calcTransformMatrix(const Pose &pose);

    static Eigen::Matrix4f calcTransformMatrix(const Eigen::Vector3f &t);

    static Eigen::Matrix4f
    calcTransformMatrix(const Eigen::Vector3f &before_vector, const Eigen::Vector3f &after_vector,
                        const Eigen::Vector3f &trans);

};


}  // robosense
}
#endif //ROBOSENSE_GEOBASE_H
