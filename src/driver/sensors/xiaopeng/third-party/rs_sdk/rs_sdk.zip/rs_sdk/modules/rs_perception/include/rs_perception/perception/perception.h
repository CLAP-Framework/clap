/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef ROBOSENSE_PERCEPTION_H
#define ROBOSENSE_PERCEPTION_H

#include "rs_perception/common/object.h"
#include <pcl/PointIndices.h>
#include "yaml-cpp/yaml.h"

namespace robosense {
namespace perception {
/**
 * @brief integrated entrance for perception sdk
 */
template<typename PointT>
class alignas(16) RobosensePerception {

public:
    typedef pcl::PointCloud<PointT> PointCloud;
    typedef typename PointCloud::Ptr PointCloudPtr;
    typedef typename PointCloud::ConstPtr PointCloudConstPtr;

    typedef std::shared_ptr<RobosensePerception<PointT>> Ptr;
    typedef std::shared_ptr<const RobosensePerception<PointT>> ConstPtr;

    /**
     * @brief constructor
     */
    RobosensePerception(const std::string &lidar_config_path,
                        const std::string &usr_config_path,
                        const std::string &deep_model_path,
                        const std::string &roi_map_path = "",
                        bool with_debug_info = false);

    /**
     * @brief another version of constructor
     *
     */
    RobosensePerception(const Pose &lidar_base,
                        const YAML::Node &sdk_use_conf,
                        const std::string &deep_model_path,
                        const std::string &roi_map_path = "",
                        bool with_debug_info = false);

    ~RobosensePerception();

    static void getVersion(std::string &version);

    /**
     * @brief main perception entrance
     */
    void perception(std::vector<typename Object<PointT>::Ptr> &percept_result,
                    std::vector<FreeSpaceInfo::Ptr> &freespace_result,
                    PointCloudConstPtr in_cloud_ptr,
                    double timestamp,
                    const Eigen::Matrix4f &v2g_mat = Eigen::Matrix4f::Identity());

    /**
     * @brief Get ground points
     */
    void getGroundPoints(PointCloudPtr &ground_cloud_ptr) const;

    void getRoiPoints(PointCloudPtr &roi_cloud_ptr) const;

    const std::vector<ErrorCode> &getErrors() const;

    double getProcessingTime() const;

private:
    class RobosensePerceptionInternal;

    RobosensePerceptionInternal *Internal;
};

} // namespace perception
} // namespace robosense

#endif //ROBOSENSE_PERCEPTION_H
