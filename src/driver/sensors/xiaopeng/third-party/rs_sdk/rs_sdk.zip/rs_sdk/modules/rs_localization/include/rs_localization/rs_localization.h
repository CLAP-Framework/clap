/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Localization Group
 * Version: 0.2.0
 * Date: 2018.05
 *
 * DESCRIPTION
 *
 * Robosense localization ROS package.
 *
 */

#ifndef RS_LOCALIZATION_H
#define RS_LOCALIZATION_H

#include <string>
#include <exception>
#include <memory>
#include <queue>
#include <mutex>
#include <thread>
#include <yaml-cpp/yaml.h>
#include <rs_common/interface/algorithm/localization_interface.h>

namespace robosense
{
namespace localization
{
// using namespace robosense::common;
class RSLocalizationImpl; /* forward declaration */

class RSLocalization : public common::LocalizationInterface
{
public:
  RSLocalization();
  RSLocalization(const std::string& name);
  ~RSLocalization();

  /* RS_SDK Interfaces */
  virtual common::ErrCode init(const std::string& base_config_path, const YAML::Node& params);
  virtual common::ErrCode start();
  virtual common::ErrCode stop();
  virtual common::ErrCode resetVehicleState(const common::VehicleStateMsg& state);
  virtual common::ErrCode getVehicleState(common::VehicleStateMsg& state, double t);
  virtual ModuleStatus getModuleStatus();
  virtual common::ErrCode getVehicleState(common::VehicleStateMsg& state);
  virtual common::ErrCode logVehicleState(common::VehicleStateMsg& state, std::string& path);
  virtual common::ErrCode getMapOriginGlobal(Eigen::Vector3d& lat_long_alt);
  virtual common::ErrCode toGlobalCoordinate(const Eigen::Vector3d& local, Eigen::Vector3d& global);
  virtual common::ErrCode getMap(common::GridMap& map);
  virtual common::ErrCode getMap(common::LidarPointsMsg& map);
  virtual double getProcessingTime();
  virtual void regExceptionCallback(const std::function<void(const common::ErrCode& exception)>&);
  virtual common::ErrCode imuCallback(const common::ImuMsg& msg);
  virtual common::ErrCode gnssCallback(const common::GnssMsg& msg);
  virtual common::ErrCode odomCallback(const common::OdomMsg& msg);
  virtual common::ErrCode lidarCallback(const common::LidarPointsMsg& msg);

  /* Legacy Interfaces */
  common::ErrCode init(const std::string& map_file, const std::string& default_param_file,
                       const std::string& param_file);
  const YAML::Node& getParam();

private:
  std::unique_ptr<RSLocalizationImpl> pimpl_;
  std::thread thread_;
  std::string map_frame_id_;
  std::string vehicle_frame_id_;
  std::function<void(const common::ErrCode& exception)> exceptionCallback_;
  /* data buffers */
  std::queue<common::ImuMsg> buff_imu_;
  std::queue<common::OdomMsg> buff_odom_;
  std::queue<common::GnssMsg> buff_gnss_;
  std::queue<common::LidarPointsMsg> buff_lidar_;
  std::mutex mx_imu_;
  std::mutex mx_odom_;
  std::mutex mx_gnss_;
  std::mutex mx_lidar_;

  bool started_ = true;
  inline void mainThread();
};

}  // namespace localization
}  // namespace robosense

#endif  // RS_LOCALIZATION_H
