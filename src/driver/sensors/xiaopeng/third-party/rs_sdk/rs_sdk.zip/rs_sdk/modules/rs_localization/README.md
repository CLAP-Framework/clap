# rs_localization
* v2.3.0

## 简介
**rs_localization** 是速腾聚创算法SDK(**rs_sdk**)中的核心模块。该模块基于高精度地图和多传感器融合技术,为自动驾驶、机器人导航等系统提供实时的定位信息。 

详细的使用说明以及API简介请参考 [README_CN.md](doc/README_CN.md)

## Introduction

rs_localization is a localization software developed by Robosense whith LiDAR as the main sensor. The algoritm is based on high-precision map and multi sensor fusion integrating LiDAR data together with IMU, RTK as well as velocity of vehicles. It can provide real-time localization infomation for autonomous driving systems.

For detailed introduction about API and usage, please refer to [README_EN.md](doc/README_EN.md)