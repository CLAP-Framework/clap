/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef ROBOSENSE_POINT_TYPES_H
#define ROBOSENSE_POINT_TYPES_H

#define PCL_NO_PRECOMPILE

#include <pcl/pcl_macros.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/impl/instantiate.hpp>

namespace robosense
{
    namespace perception
    {
        struct PointRS
        {
            PCL_ADD_POINT4D;                // preferred way of adding a XYZ+padding
            union
            {
                struct
                {
                    float intensity;
                    float distance;             //point range
                    int ring_id;                //scan ring id
                    int seq_id;                 //scan seq_id
                };
                float data_c[4];
            };
            union
            {
                struct
                {
                    double timestamp;           //point timestamp
                    int echo_id;                //point_echo
                };
                double time[2];
                float data_t[4];
            };
        }EIGEN_ALIGN16;                    // enforce SSE padding for correct memory alignment
    }
}


POINT_CLOUD_REGISTER_POINT_STRUCT (robosense::perception::PointRS,
                                   (float, x, x)
                                       (float, y, y)
                                       (float, z, z)
                                       (float, intensity, intensity)
                                       (float, distance, distance)
                                       (int, ring_id, ring_id)
                                       (int, seq_id, seq_id)
                                       (int, echo_id, echo_id)
                                       (double, timestamp, timestamp)
)

//PCL_INSTANTIATE(pcl::SampleConsensusModelPlane, PointRS);
//PCL_INSTANTIATE(pcl::RandomSampleConsensus, PointRS);

PCL_INSTANTIATE_PointCloud(robosense::perception::PointRS);

#endif //ROBOSENSE_POINT_TYPES_H
