/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef ROBOSENSE_MATH_H
#define ROBOSENSE_MATH_H

#include "rs_perception/common/basic_types.h"

namespace robosense {
namespace perception {

struct alignas(16) MathUtil {


    static float gaussianWeight(float val, float sigma, float mean = 0.f);

    static float gaussianProb(float val, float sigma, float mean = 0.f);

    static float calcAngleErr2D(const float &a, const float &b);

    static float calcAngleSum2D(const float &a, const float &b);

    static float normalizeAngle(const float &a);

    template<typename T>
    static int sign(const T &val) {
        return val >= 0 ? 1 : -1;
    }

    static bool inPolygon(int nvert, float *vertx, float *verty, float testx, float testy);

};


}
}


#endif