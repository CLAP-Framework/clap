/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef RS_LOCALIZATION_GPSMSG_H
#define RS_LOCALIZATION_GPSMSG_H

#include <iostream>
#include <stdio.h>
#include <Eigen/Core>
#include <Eigen/LU>
#include <exception>
#include "common.h"
#include "basic_types.h"

namespace robosense {
namespace perception {

class GpsTranslator {
public:
    // Gps Translate Configure Yaml Loader 
    class gpsTransformConfig {
    public:
        gpsTransformConfig() {
            longitude = 0;
            latitude = 0;
            altitude = 0;
        }

    public:
        int load(const std::string &gps_transform_config_path) {
            CommonBase commonBase;

            YAML::Node basicNode;
            try {
                basicNode = commonBase.loadFile(gps_transform_config_path);
            }
            catch (const std::exception &e) {
                COUTR("Load Gps Transform Config File Failed: " << gps_transform_config_path);
                return -1;
            }

            commonBase.yamlReadAbort<double>(basicNode, "gps_longitude", longitude);
            commonBase.yamlReadAbort<double>(basicNode, "gps_latitude", altitude);
            commonBase.yamlReadAbort<double>(basicNode, "gps_altitude", altitude);

            return 0;
        }

        void print() const {
            COUTG(" ===================== GPS Configure ================== ");
            COUTG("longitude: " << longitude);
            COUTG("latitude : " << latitude);
            COUTG("altitude : " << altitude);
            COUTG(" ===================== GPS Configure ================== ");
        }

    public:
        double longitude;
        double latitude;
        double altitude;
    };

public:
    explicit GpsTranslator();

    GpsTranslator(const std::string &gps_translate_config_path);

    void setGpsOrigin(const Eigen::Vector3d &gps_origin_lat_lon_alt);

    bool gps2xyz(const Eigen::Vector3d &lon_lat_alt, Eigen::Vector3d &xyz);

    bool gps2xyz(const double &longitude, const double &latitude, const double &altitude, Eigen::Vector3d &xyz);

    bool xyz2gps(const Eigen::Vector3d &xyz, double &longitude, double &latitude, double &altitude);

    bool xyz2gps(const Eigen::Vector3d &xyz, Eigen::Vector3d &lon_lat_alt);

    gpsTransformConfig configure() const {
        return gps_transform_config_;
    }

private:
    Eigen::Vector3d WGS84toECEF(const Eigen::Vector3d &gps);

    Eigen::Vector3d ECEFtoWGS84(const Eigen::Vector3d &xyz);

private:
    bool is_set_gps_origin_;
    std::string gps_transform_config_path_;
    gpsTransformConfig gps_transform_config_;
    Eigen::Vector3d gps_origin_;
    Eigen::Vector3d origin_ECEF_;
};

} // namespace perception
} // namespace robosense
#endif // RS_LOCALIZATION_GPSMSG_H
