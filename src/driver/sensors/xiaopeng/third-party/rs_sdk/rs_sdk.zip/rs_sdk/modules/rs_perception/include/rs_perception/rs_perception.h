/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#pragma once

#include <queue>
#include <rs_perception/common/geo_base.h>
#include <rs_perception/perception/perception.h>
#include <rs_common/common.h>
#include <rs_common/interface/algorithm/perception_interface.h>
#include <rs_common/msg/rs_msg/obstacle_msg.h>
#include <rs_common/msg/rs_msg/freespace_msg.h>
#include <rs_common/msg/rs_msg/vehiclestate_msg.h>
#include <condition_variable>

namespace robosense
{
namespace perception
{
template <typename PointT>
class RSPerception : virtual public robosense::common::PerceptionInterface<PointT>
{
public:
    typedef pcl::PointCloud<PointT> PointCloud;
    typedef typename PointCloud::Ptr PointCloudPtr;
    typedef typename PointCloud::ConstPtr PointCloudConstPtr;

    typedef std::shared_ptr<RSPerception<PointT>> Ptr;
    typedef std::shared_ptr<const RSPerception<PointT>> ConstPtr;

    RSPerception() = default; //TODO: only for test
    ~RSPerception() = default;

    common::ErrCode init(const YAML::Node &sdk_config, const std::array<double, 6> &base_pose, const std::string &config_path = "");
    common::ErrCode start();
    common::ErrCode stop();

    void regObstacleCallback(const std::function<void(const common::ObstacleMsg::Ptr &)> &cb);
    void regFreeSpaceCallback(const std::function<void(const common::FreeSpaceMsg::Ptr &)> &cb);
    void regExceptionCallback(const std::function<void(const common::ErrCode &)> &callback);

    double getProcessingTime() const;

    common::ErrCode lidarCallback(const common::LidarPointsMsg &msg);
    common::ErrCode vehiclestateCallback(const common::VehicleStateMsg &msg);

private:
    typename RobosensePerception<PointT>::Ptr robosense_perceptioner_;

    std::thread main_thread_;

    /* receiv msg data buffers */
    std::deque<common::VehicleStateMsg> buff_vehiclestate_;
    std::deque<common::LidarPointsMsg> buff_lidar_;

    std::mutex mx_vehiclestate_;
    std::mutex mx_lidar_;
    std::mutex mx_obs_cb_;
    std::mutex mx_fs_cb_;
    std::mutex mx_exc_cb_;
    std::condition_variable cv_;
    std::condition_variable cv2_;

    bool is_started_;
    bool is_init_ok_;

    int32_t perception_mode_; //0: pointcloud only, 1: with ego_pose estimation (from localization or odometry).

    std::string frame_id_;

    double frame_during_time_;

    static double MAX_TIME_OFF_LATEST;

    Eigen::Matrix4f lidar_vehicle_trans_; // trans from lidar to vehicle coord.

    std::function<void(const common::ErrCode &exception)> exceptionCallback_;
    std::vector<std::function<void(const common::ObstacleMsg::Ptr &obstacles)>> obs_cb_list_;
    std::vector<std::function<void(const common::FreeSpaceMsg::Ptr &freespaces)>> fs_cb_list_;

    inline void run();
    inline void pubObstacleMsg(const std::vector<typename Object<PointT>::Ptr> &objects,
                               const robosense::perception::Header &header);

    inline void pubFreespaceMsg(const std::vector<FreeSpaceInfo::Ptr> &freespaces,
                                const robosense::perception::Header &header);

    inline common::ErrCode tryMsg();

    bool with_debug_info_;

    //---for v2r only---
    Eigen::Matrix4f lidar_global_trans_; // trans from lidar to global coord.
    Eigen::Matrix4f lidar_base_trans_;   // trans from lidar to base coord.
    Eigen::Matrix4f base_global_trans_;  // trans from base to global coord.
};

} // namespace perception
} // namespace robosense
