#pragma once

namespace robosense
{
namespace localization
{
const uint32_t MODULE_INIT = 1;
const uint32_t KEY_CHECK = 1 << 1;
const uint32_t NOT_INIT = 1 << 2;
const uint32_t DOING_INIT = 2 << 2;
const uint32_t RETRY_INIT = 3 << 2;
const uint32_t INIT_FAIL = 4 << 2;
const uint32_t INIT_DONE = 5 << 2;
const uint32_t LOC_IDLE = 1 << 5;
const uint32_t LOC_NORMAL = 2 << 5;
const uint32_t LOC_LOW_ACRY = 3 << 5;
const uint32_t LOC_LOST = 4 << 5;
const uint32_t IMU_OVF = 1 << 8;
const uint32_t GNSS_OVF = 1 << 9;
const uint32_t ODOM_OVF = 1 << 10;
const uint32_t LIDAR_OVF = 1 << 11;

namespace loc_status
{
/* These macros are for copied from above definition and remove bit shift
  in order to making it easier to check a specified status*/
const uint32_t NOT_INIT = 1;
const uint32_t DOING_INIT = 2;
const uint32_t RETRY_INIT = 3;
const uint32_t INIT_FAIL = 4;
const uint32_t INIT_DONE = 5;
const uint32_t LOC_IDLE = 1;
const uint32_t LOC_NORMAL = 2;
const uint32_t LOC_LOW_ACRY = 3;
const uint32_t LOC_LOST = 4;
}
} /* ns: localization */
} /* ns: robosense */