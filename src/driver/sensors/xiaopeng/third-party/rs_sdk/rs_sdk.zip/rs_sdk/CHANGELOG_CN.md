## 2019-9-20
### Version

1.1.1

### Updates

- 解决感知接收端不匹配的问题

---
## 2019-9-01
### Version

1.1.0

### Updates

- 更新感知模型
- 更新proto传输部分代码,使用boost.asio库
- 新增点云proto传输(测试功能,不推荐使用)
- 解决感知rviz画图部分无点云数据时崩溃的问题

---
## 2019-8-23
### Version

1.0.1

### Updates

- 更新感知默认参数
- 更新freespace画图程序,提升效率

---

## 2019-8-1
### Version

1.0.0

### Updates

- α测试版

---


