# Robosense Perception SDK 

- v 2.5

## 简介

​	***Robosense Perception SDK*** 是速腾聚创开发的高级人工智能软件堆栈，帮助激光雷达“看到”和“理解”周围环境。它可以应用于机器人的各种场景，特别是自动驾驶，实现实时3D障碍物检测，跟踪，分类及可行驶地面点检测。

​	结合Robosense HD-Mapping高精度地图制作模块和Robosense Localization定位模块，速腾聚创可以为客户提供完整的激光雷达感知解决方案。

- 详细内容请参照 [README_CN](./../../doc/rs_perception/README_CN.md).

## Introduction

​	***Robosense Perception SDK*** is Robosense's advanced artificial-intelligence software stack helps lidar "seeing" and "understanding" the world based on data captured by one or more lidar sensors. It can be applied to a variety of scenarios for robotics especially for autonomous driving to enable realtime 3D object detection, tracking, classification and free zone detection. 

​	Companied with Robosense HD-Mapping software and Robosense Localization software, Robosense can provide clients with entire lidar perception solution. 

- please refer the [README_EN](./../../doc/rs_perception/README_EN.md) for detail.



