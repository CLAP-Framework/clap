#pragma once

class RsLocker {
public:
    static void createRsLocker(const int &authorization_id);
};
