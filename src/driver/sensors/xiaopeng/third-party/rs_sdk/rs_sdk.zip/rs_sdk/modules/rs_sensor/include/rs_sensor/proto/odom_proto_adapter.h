/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#pragma once

#ifdef PROTO_FOUND

#include <rs_common/interface/sensor/odom_interface.h>
#include <rs_common/msg/proto_msg/Proto_msg.Odom.pb.h>
#include <rs_common/msg/proto_msg_translator.h>
#include <rs_common/proto/proto_base.hpp>
namespace robosense
{
namespace sensor
{
class OdomProtoAdapter : virtual public common::OdomInterface, virtual public common::ProtoBase
{
public:
  OdomProtoAdapter() = default;
  ~OdomProtoAdapter() { stop(); }

  common::ErrCode init(const YAML::Node &config);
  common::ErrCode start();
  common::ErrCode stop();

  inline void regRecvCallback(const std::function<void(const common::OdomMsg &)> callBack)
  {
    odom_cb_.emplace_back(callBack);
  }
  inline void regExceptionCallback(const std::function<void(const common::ErrCode &)> excallBack)
  {
    excb_ = excallBack;
  }
  void send(const common::OdomMsg &msg);

private:
  inline void localCallback(const common::OdomMsg &rs_msg)
  {
    for (auto &cb : odom_cb_)
    {
        cb(rs_msg);
    }
  }
  inline void reportError(const common::ErrCode &error)
  {
    if (excb_ != NULL)
    {
      excb_(error);
    }
  }

private:
  enum state
  {
    IDLE = 0,
    RECEIVE,
    SENDMSG,
  };
  void stateMachine();

private:
  std::vector<std::function<void(const common::OdomMsg &)>> odom_cb_;
  std::function<void(const common::ErrCode &)> excb_;
  std::unique_ptr<std::thread> odom_thread_;
  bool thread_flag_;
  state self_state_;
private:
  static const uint16_t supported_api_ = 0x0001;
};
} // namespace sensor
} //namespace robosense
#endif //PROTO_FOUND