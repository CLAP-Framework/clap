/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#include <chrono>
#include <rs_perception/rs_perception.h>

namespace robosense
{
namespace perception
{

template <typename PointT>
double RSPerception<PointT>::MAX_TIME_OFF_LATEST = 0.05; //默认超过50ms就认为点云和定位没有匹配上

template <typename PointT>
common::ErrCode RSPerception<PointT>::init(const YAML::Node &sdk_config, const std::array<double, 6> &base_pose, const std::string &config_path)
{
    is_init_ok_ = false;
    is_started_ = false;
    frame_during_time_ = 0;

    //init perception processer arguments
    common::CommonBase::setName("rs_perception");

    if (config_path == "")
    {
        ERROR << common::CommonBase::name() << ": Cannot find valid config path. Aborting!!!" << REND;
        exit(-1);
    }

    perception_mode_ = 0;
    YAML::Node percept_sdk_common_config = common::CommonBase::yamlSubNodeAbort(sdk_config, std::string("common"));
    common::CommonBase::yamlReadAbort<int>(percept_sdk_common_config, std::string("perception_mode"), perception_mode_);
    if (perception_mode_ < 0 || perception_mode_ > 2)
    {
        ERROR << common::CommonBase::name() << ": Wrong perception mode setting, please recheck your config. Aborting!!!" << REND;
        exit(-1);
    }

    with_debug_info_ = false;
    common::CommonBase::yamlReadAbort<bool>(percept_sdk_common_config, std::string("with_debug_info"), with_debug_info_);
    frame_id_ = "rs-perception";
    common::CommonBase::yamlReadAbort<std::string>(percept_sdk_common_config, std::string("perception_frame_id"), frame_id_);
    float stick_height = 2.7f;
    common::CommonBase::yamlReadAbort<float>(percept_sdk_common_config, std::string("stick_height"), stick_height);

    YAML::Node percept_sdk_algorithm_config = common::CommonBase::yamlSubNodeAbort(sdk_config, std::string("algorithm"));

    std::string model_path = config_path + "/perception_config/model/deepmodel";
    std::string roi_path = config_path + "/perception_config/roi_map";

    if (perception_mode_ == 0 || perception_mode_ == 1)
    { //vehicle mode, without or with ego-motion estimation from localization or odometry
        Pose pose;
        pose.x = base_pose[0];
        pose.y = base_pose[1];
        pose.z = base_pose[2];
        pose.roll = base_pose[3];
        pose.pitch = base_pose[4];
        pose.yaw = base_pose[5];
        lidar_vehicle_trans_ = GeoUtil<PointT>::calcTransformMatrix(Eigen::Vector3f(-pose.x, -pose.y, 0));

        robosense_perceptioner_.reset(new RobosensePerception<PointT>(pose, percept_sdk_algorithm_config, model_path, roi_path, with_debug_info_));
    }
    else if (perception_mode_ == 2)
    { //v2r mode
        Pose pose;
        pose.x = base_pose[0];
        pose.y = base_pose[1];
        pose.z = base_pose[2];
        pose.roll = base_pose[3];
        pose.pitch = base_pose[4];
        pose.yaw = base_pose[5];
        lidar_global_trans_ = GeoUtil<PointT>::calcTransformMatrix(pose);

        pose.x = 0;
        pose.y = 0;
        pose.z = stick_height;
        pose.roll = 0;
        pose.pitch = 0;
        pose.yaw = 0;
        lidar_base_trans_ = GeoUtil<PointT>::calcTransformMatrix(Eigen::Vector3f(0, 0, stick_height));

        base_global_trans_ = lidar_global_trans_ * lidar_base_trans_.inverse();

        robosense_perceptioner_.reset(new RobosensePerception<PointT>(pose, percept_sdk_algorithm_config, model_path, roi_path, with_debug_info_));
    }

    is_init_ok_ = true;

    if (with_debug_info_)
    {
        if (perception_mode_ == 0)
        {
            COUTG("Perception_mode: 0, only with pointcloud as input");
        }
        else if (perception_mode_ == 1)
        {
            COUTG("Perception_mode: 1, with pointcloud and pose (can from localization or odometry) as input");
        }
        else if (perception_mode_ == 2)
        {
            COUTG("Perception_mode: 2, work in static v2r mode");
        }
    }

    return common::ErrCode_Success;
}

template <typename PointT>
common::ErrCode RSPerception<PointT>::start()
{
    is_started_ = false;
    if (is_init_ok_)
    {
        is_started_ = true;
        COUTY("rs-perception is started ...");
        main_thread_ = std::thread([this] { run(); });
        return common::ErrCode_Success;
    }
    else
    {
        ERROR << common::CommonBase::name() << ": Incorrect initialized perception. Aborting!!!" << REND;
        return common::ErrCode_PerceptionInitError;
    }
}

template <typename PointT>
common::ErrCode RSPerception<PointT>::stop()
{
    is_started_ = false;
    cv_.notify_all();
    cv2_.notify_all();
    if (main_thread_.joinable())
    {
        main_thread_.join();
    }

    robosense_perceptioner_.reset();
    COUTY("rs-perception is stoped.");
    return common::ErrCode::ErrCode_Success;
}

template <typename PointT>
double RSPerception<PointT>::getProcessingTime() const
{
    return frame_during_time_;
}

template <typename PointT>
void RSPerception<PointT>::regObstacleCallback(const std::function<void(const common::ObstacleMsg::Ptr &)> &cb)
{
    std::lock_guard<std::mutex> lg(mx_obs_cb_);
    obs_cb_list_.emplace_back(cb);
}

template <typename PointT>
void RSPerception<PointT>::regFreeSpaceCallback(const std::function<void(const common::FreeSpaceMsg::Ptr &)> &cb)
{
    std::lock_guard<std::mutex> lg(mx_fs_cb_);
    fs_cb_list_.emplace_back(cb);
}

template <typename PointT>
void RSPerception<PointT>::regExceptionCallback(const std::function<void(const common::ErrCode &exception)> &callback)
{
    std::lock_guard<std::mutex> lg(mx_exc_cb_);
    exceptionCallback_ = callback;
}

template <typename PointT>
common::ErrCode RSPerception<PointT>::lidarCallback(const common::LidarPointsMsg &msg)
{
    {
        std::lock_guard<std::mutex> lk(mx_lidar_);
        buff_lidar_.emplace_back(msg);
        cv_.notify_all();
    }

    return common::ErrCode::ErrCode_Success;
}

template <typename PointT>
common::ErrCode RSPerception<PointT>::vehiclestateCallback(const common::VehicleStateMsg &msg)
{
    {
        std::lock_guard<std::mutex> lk(mx_vehiclestate_);
        buff_vehiclestate_.emplace_back(msg);
        cv2_.notify_all();
    }

    return common::ErrCode_Success;
}

template <typename PointT>
void RSPerception<PointT>::run()
{
    common::LidarPointsMsg current_lidar_msg;
    common::VehicleStateMsg current_vehiclestate_msg;
    robosense::perception::Header header;
    robosense::perception::Pose pose;
    Eigen::Matrix4f v2g_mat = Eigen::Matrix4f::Identity();

    int frame_cnt = 0;

    while (is_started_)
    {
        if (perception_mode_ == 0)
        {

            {
                /* Lidar mutex lock scope */
                std::unique_lock<std::mutex> lk(mx_lidar_);
                if (this->buff_lidar_.empty() && is_started_)
                {
                    cv_.wait(lk);
                }
                if (!is_started_)
                {
                    continue;
                }
                current_lidar_msg = buff_lidar_.front();
                buff_lidar_.clear();
            }

            if (with_debug_info_)
            {
                COUTG("----------------------RS-Perception: " << frame_cnt++ << "----------------------");
            }

            //update the header info
            header.parent_frame_id = current_lidar_msg.frame_id;
            header.frame_id = frame_id_;
            header.seq = current_lidar_msg.seq;
            header.timestamp = current_lidar_msg.timestamp;
            // sdk process
            std::vector<typename Object<PointT>::Ptr> objects;
            std::vector<FreeSpaceInfo::Ptr> freespaces;

            PointCloudPtr input_cloud_ptr(new PointCloud);
            pcl::transformPointCloud(*current_lidar_msg.cloudPtr, *input_cloud_ptr, lidar_vehicle_trans_);
            robosense_perceptioner_->perception(objects, freespaces, input_cloud_ptr, current_lidar_msg.timestamp, v2g_mat);
            frame_during_time_ = robosense_perceptioner_->getProcessingTime();

            // translate to rs_msg
            pubObstacleMsg(objects, header);
            pubFreespaceMsg(freespaces, header);
        }
        else if (perception_mode_ == 1)
        {

            {
                /* Lidar mutex lock scope */
                std::unique_lock<std::mutex> lk(mx_lidar_);
                if (this->buff_lidar_.empty() && is_started_)
                {
                    cv_.wait(lk);
                }
                if (!is_started_)
                {
                    continue;
                }
                current_lidar_msg = buff_lidar_.front();
                buff_lidar_.pop_front();
                if (buff_lidar_.size() > 5)
                { //in case if the msg is getting stucked and cause mem leak.
                    buff_lidar_.clear();
                }
            }

            {
                /* VehicleState mutex lock scope */
                std::unique_lock<std::mutex> lk(mx_vehiclestate_);
                //wait until the newrest pose msg come
                while ((this->buff_vehiclestate_.empty() || this->buff_vehiclestate_.back().timestamp < current_lidar_msg.timestamp) && is_started_)
                {
                    cv2_.wait(lk);
                }
                size_t v_size = buff_vehiclestate_.size();
                if (v_size > 1)
                {
                    size_t idx = v_size - 1;
                    for (auto iter = buff_vehiclestate_.rbegin(); iter != buff_vehiclestate_.rend(); iter++, idx--)
                    {

                        if (iter->timestamp >= current_lidar_msg.timestamp)
                        { //current lidar msg time as anchor
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                    current_vehiclestate_msg = buff_vehiclestate_[++idx];
                }
                else
                {
                    current_vehiclestate_msg = buff_vehiclestate_.back();
                }

                //clear no need old msgs
                for (auto iter = buff_vehiclestate_.begin(); iter != buff_vehiclestate_.end(); iter++)
                {
                    if (iter->timestamp < current_vehiclestate_msg.timestamp)
                    {
                        buff_vehiclestate_.pop_front();
                    }
                }
            }

            if (abs(current_vehiclestate_msg.timestamp - current_lidar_msg.timestamp) > MAX_TIME_OFF_LATEST)
            {
                WARNING << common::CommonBase::name() << ": Miss Matched Messages Occured!" << END;
                continue;
            }

            if (is_started_)
            {
                if (with_debug_info_)
                {
                    COUTG("----------------------RS-Perception: " << frame_cnt++ << "----------------------");
                }

                //update the header info
                header.parent_frame_id = current_lidar_msg.frame_id;
                header.frame_id = frame_id_;
                header.seq = current_lidar_msg.seq;
                header.timestamp = current_lidar_msg.timestamp;

                pose.x = current_vehiclestate_msg.pos[0];
                pose.y = current_vehiclestate_msg.pos[1];
                pose.z = current_vehiclestate_msg.pos[2];
                pose.roll = current_vehiclestate_msg.orien[0];
                pose.pitch = current_vehiclestate_msg.orien[1];
                pose.yaw = current_vehiclestate_msg.orien[2];

                v2g_mat = GeoUtil<Point>::calcTransformMatrix(pose);

                // sdk process
                std::vector<typename Object<PointT>::Ptr> objects;
                std::vector<FreeSpaceInfo::Ptr> freespaces;

                PointCloudPtr input_cloud_ptr(new PointCloud);
                pcl::transformPointCloud(*current_lidar_msg.cloudPtr, *input_cloud_ptr, lidar_vehicle_trans_);
                robosense_perceptioner_->perception(objects, freespaces, input_cloud_ptr, current_lidar_msg.timestamp, v2g_mat);
                frame_during_time_ = robosense_perceptioner_->getProcessingTime();

                // translate to rs_msg
                pubObstacleMsg(objects, header);
                pubFreespaceMsg(freespaces, header);
            }
        }
        else if (perception_mode_ == 2)
        { //V2R Mode

            {
                /* Lidar mutex lock scope */
                std::unique_lock<std::mutex> lk(mx_lidar_);
                if (this->buff_lidar_.empty() && is_started_)
                {
                    cv_.wait(lk);
                }
                if (!is_started_)
                {
                    continue;
                }
                current_lidar_msg = buff_lidar_.front();
                buff_lidar_.clear();
            }

            if (with_debug_info_)
            {
                COUTG("----------------------RS-Perception: " << frame_cnt++ << "----------------------");
            }

            //update the header info
            header.parent_frame_id = current_lidar_msg.frame_id;
            header.frame_id = frame_id_;
            header.seq = current_lidar_msg.seq;
            header.timestamp = current_lidar_msg.timestamp;
            // sdk process
            std::vector<typename Object<PointT>::Ptr> objects;
            std::vector<FreeSpaceInfo::Ptr> freespaces;

            PointCloudPtr input_cloud_ptr(new PointCloud);
            pcl::transformPointCloud(*current_lidar_msg.cloudPtr, *input_cloud_ptr, base_global_trans_.inverse());
            robosense_perceptioner_->perception(objects, freespaces, input_cloud_ptr, current_lidar_msg.timestamp, base_global_trans_);
            frame_during_time_ = robosense_perceptioner_->getProcessingTime();

            // translate to rs_msg
            pubObstacleMsg(objects, header);
            pubFreespaceMsg(freespaces, header);
        }

        if (is_started_)
        {
            //capture exception
            const std::vector<perception::ErrorCode> erros = robosense_perceptioner_->getErrors();
            for (size_t i = 0; i < erros.size(); ++i)
            {
                switch (erros[i])
                {
                case perception::ErrCode_Success:
                {
                    std::unique_lock<std::mutex> lk(mx_exc_cb_);
                    exceptionCallback_(common::ErrCode_Success);
                    break;
                }
                case perception::ErrCode_NullInput:
                {
                    std::unique_lock<std::mutex> lk(mx_exc_cb_);
                    exceptionCallback_(common::ErrCode_PerceptionNullInput);
                    break;
                }
                case perception::ErrCode_BadRotateCalib:
                {
                    std::unique_lock<std::mutex> lk(mx_exc_cb_);
                    exceptionCallback_(common::ErrCode_PerceptionBadRotateCalibration);
                    break;
                }
                case perception::ErrCode_BadHeightCalib:
                {
                    std::unique_lock<std::mutex> lk(mx_exc_cb_);
                    exceptionCallback_(common::ErrCode_PerceptionBadHeightCalibration);
                    break;
                }
                case perception::ErrCode_GndInitFalse:
                {
                    std::unique_lock<std::mutex> lk(mx_exc_cb_);
                    exceptionCallback_(common::ErrCode_PerceptionGroundInitFalse);
                    break;
                }
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}

template <typename PointT>
void RSPerception<PointT>::pubFreespaceMsg(const std::vector<FreeSpaceInfo::Ptr> &freespaces,
                                           const robosense::perception::Header &header)
{
    //fill the msg header
    common::FreeSpaceMsg::Ptr freespace_msg(new common::FreeSpaceMsg);
    freespace_msg->frame_id = header.frame_id;
    freespace_msg->parent_frame_id = header.parent_frame_id;
    freespace_msg->seq = header.seq;
    freespace_msg->timestamp = header.timestamp;

    freespace_msg->freespaces.resize(freespaces.size());
    for (size_t i = 0; i < freespaces.size(); ++i)
    {
        const typename robosense::perception::FreeSpaceInfo::Ptr &fs = freespaces[i];
        robosense::common::FreeSpace::Ptr &rs_fs = freespace_msg->freespaces[i];
        rs_fs.reset(new common::FreeSpace);

        rs_fs->timestamp = fs->timestamp;
        rs_fs->device_code = fs->device_code;
        rs_fs->distance = fs->distance;
        rs_fs->yaw_angle = fs->yaw_angle;
        rs_fs->free_prob = fs->free_prob;
    }

    std::unique_lock<std::mutex> lk(mx_fs_cb_);
    if (!fs_cb_list_.empty())
    {
        for (auto &cb : fs_cb_list_)
            cb(freespace_msg);
    }
}

template <typename PointT>
void RSPerception<PointT>::pubObstacleMsg(const std::vector<typename Object<PointT>::Ptr> &objects,
                                          const robosense::perception::Header &header)
{

    //fill the msg header
    common::ObstacleMsg::Ptr obstacles_msg(new common::ObstacleMsg);
    obstacles_msg->frame_id = header.frame_id;
    obstacles_msg->parent_frame_id = header.parent_frame_id;
    obstacles_msg->seq = header.seq;
    obstacles_msg->timestamp = header.timestamp;

    //fill obstacles msg
    obstacles_msg->obstacles.resize(objects.size());
    for (size_t i = 0; i < objects.size(); ++i)
    {
        const typename robosense::perception::Object<PointT>::Ptr &obj = objects[i];
        robosense::common::Obstacle::Ptr &obs = obstacles_msg->obstacles[i];
        obs.reset(new robosense::common::Obstacle);

        obs->timestamp = obj->timestamp;
        obs->device_code = obj->device_code;
        obs->id = obj->id;
        obs->anchor.x = obj->anchor[0];
        obs->anchor.y = obj->anchor[1];
        obs->anchor.z = obj->anchor[2];

        obs->geo_center.x = obj->center[0];
        obs->geo_center.y = obj->center[1];
        obs->geo_center.z = obj->center[2];

        obs->geo_size.x = obj->size[0];
        obs->geo_size.y = obj->size[1];
        obs->geo_size.z = obj->size[2];

        obs->geo_direction.x = obj->direction[0];
        obs->geo_direction.y = obj->direction[1];
        obs->geo_direction.z = obj->direction[2];

        obs->polygon.resize(obj->polygon->size());
        for (size_t k = 0; k < obj->polygon->size(); ++k)
        {
            obs->polygon[k].x = obj->polygon->points[k].x;
            obs->polygon[k].y = obj->polygon->points[k].y;
            obs->polygon[k].z = obj->polygon->points[k].z;
        }

        obs->detect_confidence = obj->detect_confidence;

        obs->nearest_point.x = obj->nearest_point[0];
        obs->nearest_point.y = obj->nearest_point[1];
        obs->nearest_point.z = obj->nearest_point[2];

        obs->left_point.x = obj->left_point[0];
        obs->left_point.y = obj->left_point[1];
        obs->left_point.z = obj->left_point[2];

        obs->right_point.x = obj->right_point[0];
        obs->right_point.y = obj->right_point[1];
        obs->right_point.z = obj->right_point[2];

        obs->distance = obj->distance;
        obs->yaw = obj->yaw;
        obs->point_num = obj->point_num;

        //------------classification info------------
        obs->type = static_cast<common::ObjectType>(obj->type);
        obs->type_confidence = obj->type_confidence;
        obs->latent_types.resize(obj->latent_types.size());
        for (size_t k = 0; k < obj->latent_types.size(); ++k)
        {
            obs->latent_types[k] = obj->latent_types[k];
        }

        obs->motion_state = static_cast<common::MotionType>(obj->motion_state);

        //------------tracking info------------
        obs->is_track_converged = obj->is_track_converged;
        obs->tracker_id = obj->tracker_id;

        obs->velocity.x = obj->velocity[0];
        obs->velocity.y = obj->velocity[1];
        obs->velocity.z = obj->velocity[2];
        for (size_t k = 0; k < 9; ++k)
        {
            obs->velocity_cov[k] = obj->velocity_cov(k);
        }
        obs->velocity_uncertainty = obj->velocity_uncertainty;
        obs->ave_velocity.x = obj->ave_velocity[0];
        obs->ave_velocity.y = obj->ave_velocity[1];
        obs->ave_velocity.z = obj->ave_velocity[2];

        obs->acceleration.x = obj->acceleration[0];
        obs->acceleration.y = obj->acceleration[1];
        obs->acceleration.z = obj->acceleration[2];
        for (size_t k = 0; k < 9; ++k)
        {
            obs->acceleration_cov[k] = obj->acceleration_cov(k);
        }
        obs->acceleration_uncertainty = obj->acceleration_uncertainty;
        obs->ave_acceleration.x = obj->ave_acceleration[0];
        obs->ave_acceleration.y = obj->ave_acceleration[1];
        obs->ave_acceleration.z = obj->ave_acceleration[2];

        obs->angle_velocity = obj->angle_velocity;
        obs->angle_velocity_cov = obj->angle_velocity_cov;
        obs->angle_velocity_uncertainty = obj->angle_velocity_uncertainty;
        obs->ave_angle_velocity = obj->ave_angle_velocity;

        obs->asso_quality = obj->asso_quality;
        obs->tracker_quality = obj->tracker_quality;
        obs->tracking_time = obj->tracking_time;
    }

    std::unique_lock<std::mutex> lk(mx_obs_cb_);
    if (!obs_cb_list_.empty())
    {
        for (auto &cb : obs_cb_list_)
            cb(obstacles_msg);
    }
}

template class RSPerception<pcl::PointXYZI>;

} // namespace perception
} // namespace robosense