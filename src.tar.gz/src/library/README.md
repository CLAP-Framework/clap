# ZZZ_common

This directory contains the `zzz_common` package that is commonly used. It also imports other common dependencies like tensor operation library, build configurations, etc.

TODO: This library should be finally written in C++ or Cython.

# Reference

Motion Models:
'''tex
@inproceedings{schubert2008comparison,
  title={Comparison and evaluation of advanced motion models for vehicle tracking},
  author={Schubert, Robin and Richter, Eric and Wanielik, Gerd},
  booktitle={2008 11th international conference on information fusion},
  pages={1--6},
  year={2008},
  organization={IEEE}
}
'''
