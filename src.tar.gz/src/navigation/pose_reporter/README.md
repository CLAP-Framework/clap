This package subscribe tf and odom messages to convert odometry result into RigidBodyState in map frame.

The `manual` node just takes one GPS and one odometry as input.
