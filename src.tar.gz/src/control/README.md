This module contains essential vehicle controllers.
