This module contains packages for environment cognition.
