This module contains packages for autonomous planning.

- **Decision**: Making decision according to environment
- **Routing**: Global path planner
- **Local**: Local trajectory planner
