from .basic import PSMNet as basic
from .stackhourglass import PSMNet as stackhourglass

