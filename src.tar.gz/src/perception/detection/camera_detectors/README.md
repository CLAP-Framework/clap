# Reference
https://github.com/ultralytics/yolov3

# Result coordinate
x, y are in NED coordinate
