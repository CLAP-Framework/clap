# Package Summary
This package contains filters on detected objects.
