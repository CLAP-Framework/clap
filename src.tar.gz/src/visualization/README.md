This module contains packages for system and data visualization.

- **web**: Modules for web based rendering
- **rviz**: Modules for visualization in RViz
